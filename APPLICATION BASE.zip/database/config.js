module.exports = {
  tokens: "8243568634:AAHzvMsPe7wDqlyqMXWUd9xqlu0ung9MV6c",
  owners: "2113286230",
  port: "2000",
  ipvps: "165.22.107.158"
};
