module.exports = {
  tokens: "8518906122:AAGySAYRxTf15pG513pp438VhHPYxmWNaVQ", 
  owner: "7300602830", 
  port: "4405", // Ini Wajib Jangan Diubah
  ipvps: "https://104.248.159.238" // Jangan Diubah Nanti Eror!!
};